//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var myAge : Int = 32

myAge = 33

let myName : String = "Dasiy"

let myAgeForReal = myAge - 8

let myDetails = "\(myName),\(myAgeForReal)"

//Creating the getMilk() function
func getMilk(){
    print("go to the shops")
    print("buy 2 cartons of milk")
    print("Pay $2")
    print("come home")
}

//Calling the getMilk() function
getMilk()

//Define how many milk cartons to buy and how much to pay by input value
func getMilk2(howManyMilkCartons: Int){
    print("go to the shops")
    print("buy \(howManyMilkCartons) cartons of milk")
    let priceToPay = howManyMilkCartons * 2
    print("Pay $\(priceToPay)")
    print("come home")
    
}

getMilk2(howManyMilkCartons: 4)

//Know how much change should return
func getMilk3(howManyMilkCartons: Int, howMuchMoneyRootWasGin : Int) -> Int {
    print("go to the shops")
    print("buy \(howManyMilkCartons) cartons of milk")
    
    let priceToPay = howManyMilkCartons * 2
    
    print("Pay $\(priceToPay)")
    print("come home")
    
    let change = howMuchMoneyRootWasGin - priceToPay
    
    return change
    
}

 var amountOfChange = getMilk3(howManyMilkCartons: 1, howMuchMoneyRootWasGin: 10)

print("Hello master, here's your $\(amountOfChange) change")



